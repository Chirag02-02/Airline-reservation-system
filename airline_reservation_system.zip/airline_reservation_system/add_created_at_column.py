import sqlite3

conn = sqlite3.connect("airline.db")
cur = conn.cursor()

try:
    # Check if 'created_at' column already exists
    cur.execute("PRAGMA table_info(users);")
    columns = [col[1] for col in cur.fetchall()]

    if 'created_at' not in columns:
        # Add column without default
        cur.execute("ALTER TABLE users ADD COLUMN created_at TEXT")
        conn.commit()
        print("✅ 'created_at' column added successfully.")

        # Update existing rows with current timestamp
        cur.execute("UPDATE users SET created_at = datetime('now')")
        conn.commit()
        print("✅ Existing rows updated with timestamps.")
    else:
        print("ℹ️ 'created_at' column already exists.")
except Exception as e:
    print("❌ Error:", e)
finally:
    conn.close()
