import sqlite3

conn = sqlite3.connect("airline.db")
cur = conn.cursor()

# ✅ Create admin table if it doesn't exist
cur.execute("""
CREATE TABLE IF NOT EXISTS admin (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL
)
""")

# ✅ Add default admin (only once)
cur.execute("INSERT OR IGNORE INTO admin (username, password) VALUES (?, ?)", ("admin", "admin123"))

conn.commit
