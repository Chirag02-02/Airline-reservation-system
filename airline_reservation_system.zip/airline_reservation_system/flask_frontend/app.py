from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
import os
from functools import wraps
import math

# -----------------------------
# Config & Database utilities
# -----------------------------
app = Flask(__name__)
# For development use an environment variable; fallback to a dev secret
app.secret_key = os.environ.get("SECRET_KEY", "dev_secret_key_please_change")

# DB file is in project root (one level up from this package)
import os
import sqlite3

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = r"C:\Users\chaud\Desktop\airline_reservation_system\airline.db"

def get_db_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # optional, makes results dict-like
    return conn


# -----------------------------
# Admin protection decorator
# -----------------------------
def admin_required(f):
    @wraps(f)
    def secure_route(*args, **kwargs):
        if 'admin_logged_in' not in session:
            return redirect(url_for('admin_login'))
        return f(*args, **kwargs)
    return secure_route


# -----------------------------
# Initialization (run on startup)
# -----------------------------
def init_db():
    conn = get_db_conn()
    cur = conn.cursor()
    cur.executescript("""
    PRAGMA foreign_keys = ON;

    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS flights (
        flight_id INTEGER PRIMARY KEY AUTOINCREMENT,
        flight_no TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL,
        source TEXT NOT NULL,
        destination TEXT NOT NULL,
        date TEXT NOT NULL,
        time TEXT NOT NULL,
        seats INTEGER NOT NULL,
        price REAL NOT NULL
    );

    CREATE TABLE IF NOT EXISTS bookings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        flight_id INTEGER NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (flight_id) REFERENCES flights(flight_id)
    );

    CREATE TABLE IF NOT EXISTS admin (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL
    );
    """)

    # ensure an admin exists (only insert if table empty)
    cur.execute("SELECT COUNT(*) FROM admin")
    if cur.fetchone()[0] == 0:
        cur.execute("INSERT INTO admin (username, password) VALUES (?, ?)", ("admin", "admin123"))

    conn.commit()
    conn.close()

# run on import/startup
init_db()

# -----------------------------
# Public routes (user-facing)
# -----------------------------
@app.route('/')
def home():
    return render_template('home.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name'].strip()
        email = request.form['email'].strip()
        password = request.form['password']

        try:
            conn = get_db_conn()
            cur = conn.cursor()
            cur.execute("INSERT INTO users (name, email, password) VALUES (?, ?, ?)", (name, email, password))
            conn.commit()
            flash("✅ Registration successful! Please login.", "success")
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash("❌ Email already registered!", "error")
        finally:
            conn.close()

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email'].strip()
        password = request.form['password']

        conn = get_db_conn()
        cur = conn.cursor()
        cur.execute("SELECT id, name FROM users WHERE email=? AND password=?", (email, password))
        user = cur.fetchone()
        conn.close()

        if user:
            session['user_id'] = user[0]
            session['username'] = user[1]
            flash(f"✅ Welcome, {user[1]}!", "success")
            return redirect(url_for('home'))
        else:
            flash("❌ Invalid email or password.", "error")

    return render_template('login.html')

# -----------------------------
# Flights (search / sort / pagination)
# -----------------------------
@app.route('/flights')
def view_flights():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    source = request.args.get('source', '').strip()
    destination = request.args.get('destination', '').strip()
    date = request.args.get('date', '').strip()
    sort = request.args.get('sort', 'date')

    try:
        page = int(request.args.get('page', 1))
    except ValueError:
        page = 1
    per_page = 6
    if page < 1:
        page = 1

    where_clauses = []
    params = []
    if source:
        where_clauses.append("LOWER(source) LIKE ?")
        params.append("%" + source.lower() + "%")
    if destination:
        where_clauses.append("LOWER(destination) LIKE ?")
        params.append("%" + destination.lower() + "%")
    if date:
        where_clauses.append("date = ?")
        params.append(date)

    where = ""
    if where_clauses:
        where = "WHERE " + " AND ".join(where_clauses)

    order_map = {
        "price_asc": "ORDER BY price ASC",
        "price_desc": "ORDER BY price DESC",
        "date": "ORDER BY date, time",
        "airline": "ORDER BY name ASC"
    }
    order_clause = order_map.get(sort, "ORDER BY date, time")

    conn = get_db_conn()
    cur = conn.cursor()

    count_query = f"SELECT COUNT(*) FROM flights {where}"
    cur.execute(count_query, params)
    total = cur.fetchone()[0] or 0
    total_pages = max(1, math.ceil(total / per_page))
    if page > total_pages:
        page = total_pages

    offset = (page - 1) * per_page

    query = f"""
        SELECT flight_id, flight_no, name, source, destination, date, time, seats, price
        FROM flights
        {where}
        {order_clause}
        LIMIT ? OFFSET ?
    """
    query_params = params + [per_page, offset]
    cur.execute(query, query_params)
    flights = cur.fetchall()
    conn.close()

    return render_template(
        'flights.html',
        flights=flights,
        sort=sort,
        page=page,
        total_pages=total_pages,
        per_page=per_page,
        total_flights=total
    )

# -----------------------------
# Booking routes
# -----------------------------
@app.route('/book/<int:flight_id>')
def book_flight(flight_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    user_id = session['user_id']
    conn = get_db_conn()
    cur = conn.cursor()

    cur.execute("SELECT * FROM flights WHERE flight_id=?", (flight_id,))
    flight = cur.fetchone()

    if flight and flight[7] > 0:
        cur.execute("INSERT INTO bookings (user_id, flight_id) VALUES (?, ?)", (user_id, flight_id))
        cur.execute("UPDATE flights SET seats = seats - 1 WHERE flight_id=?", (flight_id,))
        conn.commit()
        conn.close()
        flash("✅ Flight booked successfully!", "success")
        return render_template('booking_success.html', flight=flight)
    else:
        conn.close()
        flash("❌ Flight not found or no seats available.", "error")
        return redirect(url_for('view_flights'))

# -----------------------------
# My bookings with pagination
# -----------------------------
@app.route('/my_bookings')
def my_bookings():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    user_id = session['user_id']
    try:
        page = int(request.args.get('page', 1))
    except ValueError:
        page = 1
    limit = 5
    offset = (page - 1) * limit

    conn = get_db_conn()
    cur = conn.cursor()
    cur.execute("""
        SELECT f.flight_no, f.name, f.source, f.destination, f.date, f.time, b.id
        FROM bookings b
        JOIN flights f ON b.flight_id = f.flight_id
        WHERE b.user_id = ?
        LIMIT ? OFFSET ?
    """, (user_id, limit, offset))
    bookings = cur.fetchall()

    cur.execute("SELECT COUNT(*) FROM bookings WHERE user_id = ?", (user_id,))
    total = cur.fetchone()[0]
    conn.close()

    total_pages = (total + limit - 1) // limit if total > 0 else 1

    return render_template('my_bookings.html', bookings=bookings, page=page, total_pages=total_pages)

# -----------------------------
# Cancel booking
# -----------------------------
@app.route('/cancel/<int:booking_id>')
def cancel_booking(booking_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    conn = get_db_conn()
    cur = conn.cursor()
    cur.execute("SELECT flight_id FROM bookings WHERE id=?", (booking_id,))
    result = cur.fetchone()

    if result:
        flight_id = result[0]
        cur.execute("DELETE FROM bookings WHERE id=?", (booking_id,))
        cur.execute("UPDATE flights SET seats = seats + 1 WHERE flight_id=?", (flight_id,))
        conn.commit()
        flash("✅ Booking cancelled successfully!", "success")
    else:
        flash("❌ Booking not found.", "error")

    conn.close()
    return redirect(url_for('my_bookings'))

# -----------------------------
# Logout (user)
# -----------------------------
@app.route('/admin/logout')
def admin_logout():
    session.clear()
    flash("👋 Logged out successfully.", "success")
    return redirect(url_for('admin_login'))   # go back to login page

# -----------------------------
@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("SELECT * FROM admin WHERE username=? AND password=?", (username, password))
        admin = cur.fetchone()
        conn.close()

        if admin:
            session["admin_logged_in"] = True
            return redirect("/admin/dashboard")
        else:
            return render_template("admin_login.html", error="Invalid username or password")

    return render_template("admin_login.html")


@app.route("/admin/dashboard")
@admin_required
def admin_dashboard():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    cur.execute("SELECT COUNT(*) FROM users")
    users_count = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM flights")
    flights_count = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM bookings")
    bookings_count = cur.fetchone()[0]

    conn.close()

    return render_template("admin_dashboard.html",
                           users_count=users_count,
                           flights_count=flights_count,
                           bookings_count=bookings_count)



@app.route('/admin/flights', methods=['GET', 'POST'])
@admin_required
def admin_flights():
    conn = get_db_conn()
    cur = conn.cursor()

    if request.method == 'POST':
        flight_no = request.form['flight_no']
        name = request.form['name']
        source = request.form['source']
        destination = request.form['destination']
        date = request.form['date']
        time = request.form['time']
        seats = request.form['seats']
        price = request.form['price']

        cur.execute("INSERT INTO flights (flight_no, name, source, destination, date, time, seats, price) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (flight_no, name, source, destination, date, time, seats, price))
        conn.commit()

    cur.execute("SELECT * FROM flights ORDER BY date, time")
    flights = cur.fetchall()
    conn.close()

    return render_template('admin_flights.html', flights=flights)

@app.route('/admin/delete_flight/<int:flight_id>')
@admin_required
def admin_delete_flight(flight_id):
    conn = get_db_conn()
    cur = conn.cursor()
    cur.execute("DELETE FROM flights WHERE flight_id=?", (flight_id,))
    conn.commit()
    conn.close()
    flash('🗑 Flight deleted successfully!', 'success')
    return redirect(url_for('admin_flights'))

@app.route('/admin/users')
@admin_required
def admin_users():
    conn = get_db_conn()
    cur = conn.cursor()
    cur.execute("SELECT id, name, email, created_at FROM users ORDER BY created_at DESC")
    users = cur.fetchall()
    conn.close()
    return render_template('admin_users.html', users=users)

@app.route('/admin/add_flight', methods=['GET', 'POST'])
@admin_required
def admin_add_flight():
    if request.method == 'POST':
        flight_no = request.form['flight_no']
        name = request.form['name']
        source = request.form['source']
        destination = request.form['destination']
        date = request.form['date']
        time = request.form['time']
        seats = request.form['seats']
        price = request.form['price']

        conn = get_db_conn()
        cur = conn.cursor()

        cur.execute("""
            INSERT INTO flights (flight_no, name, source, destination, date, time, seats, price)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (flight_no, name, source, destination, date, time, seats, price))

        conn.commit()
        conn.close()

        flash("✈️ Flight added successfully!", "success")
        return redirect(url_for('admin_flights'))

    return render_template('add_flight.html')


@app.route('/admin/bookings')
def admin_bookings():
    if 'admin_logged_in' not in session:
        return redirect(url_for('admin_login'))

    conn = get_db_conn()
    cur = conn.cursor()

    cur.execute("""
        SELECT 
            b.id AS booking_id,
            u.name AS user_name,
            f.flight_no,
            f.source,
            f.destination,
            f.date,
            f.time,
            b.num_seats AS seats
        FROM bookings b
        JOIN users u ON b.user_id = u.id
        JOIN flights f ON b.flight_id = f.flight_id
        ORDER BY b.id DESC
    """)

    bookings = cur.fetchall()
    conn.close()

    return render_template("admin_bookings.html", bookings=bookings)

@app.route('/admin/edit_flight/<int:flight_id>', methods=['GET', 'POST'])
@admin_required
def admin_edit_flight(flight_id):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    # Load existing flight data
    cur.execute("SELECT * FROM flights WHERE flight_id=?", (flight_id,))
    flight = cur.fetchone()

    if not flight:
        flash("❌ Flight not found!", "error")
        return redirect(url_for('admin_flights'))

    # Save updated data
    if request.method == 'POST':
        flight_no = request.form['flight_no']
        name = request.form['name']
        source = request.form['source']
        destination = request.form['destination']
        date = request.form['date']
        time = request.form['time']
        seats = request.form['seats']
        price = request.form['price']

        cur.execute("""
            UPDATE flights 
            SET flight_no=?, name=?, source=?, destination=?, date=?, time=?, seats=?, price=?
            WHERE flight_id=?
        """, (flight_no, name, source, destination, date, time, seats, price, flight_id))

        conn.commit()
        conn.close()

        flash("✏️ Flight updated successfully!", "success")
        return redirect(url_for('admin_flights'))

    conn.close()
    return render_template('edit_flight.html', flight=flight)

@app.route("/admin/settings", methods=["GET", "POST"])
@admin_required
def admin_settings():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    if request.method == "POST":
        system_name = request.form["system_name"]
        contact_email = request.form["contact_email"]
        contact_phone = request.form["contact_phone"]
        max_seats = request.form["max_seats"]
        allow_last_minute = 1 if request.form.get("allow_last_minute") else 0
        auto_cancel_hours = request.form["auto_cancel_hours"]
        currency = request.form["currency"]
        maintenance_mode = 1 if request.form.get("maintenance_mode") else 0
        maintenance_message = request.form["maintenance_message"]

        cur.execute("""
            UPDATE settings SET
                system_name=?, contact_email=?, contact_phone=?,
                max_seats_per_booking=?, allow_last_minute_booking=?, auto_cancel_hours=?,
                currency=?, maintenance_mode=?, maintenance_message=?
            WHERE id=1
        """, (
            system_name, contact_email, contact_phone,
            max_seats, allow_last_minute, auto_cancel_hours,
            currency, maintenance_mode, maintenance_message
        ))

        conn.commit()
        conn.close()

        flash("✔ Settings updated successfully!", "success")
        return redirect(url_for("admin_settings"))

    # Load current settings
    cur.execute("SELECT * FROM settings WHERE id=1")
    settings = cur.fetchone()
    conn.close()

    return render_template("admin_settings.html", settings=settings)





# -----------------------------
# Run app
# -----------------------------

if __name__ == "__main__":
    app.run(debug=True)

