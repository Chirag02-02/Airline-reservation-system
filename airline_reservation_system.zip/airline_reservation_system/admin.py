import sqlite3
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

def export_passenger_list_to_pdf(passengers):
    filename = "passenger_list.pdf"
    c = canvas.Canvas(filename, pagesize=letter)
    c.setFont("Helvetica-Bold", 14)
    c.drawString(200, 750, "✈️ Passenger List Report")

    c.setFont("Helvetica", 10)
    y = 720
    for p in passengers:
        line = f"User: {p[0]} | Flight: {p[1]} ({p[2]}) | {p[3]} → {p[4]} | {p[5]} | {p[6]}"
        c.drawString(50, y, line)
        y -= 20
        if y < 50:
            c.showPage()
            y = 750

    c.save()
    print(f"📄 Passenger list exported successfully as '{filename}'.")


# --- Admin Functions ---

import sqlite3

def add_flight():
    conn = sqlite3.connect("airline.db")
    cur = conn.cursor()

    print("\n===== ✈️ Add New Flight =====")
    name = input("Enter Airline Name: ")
    source = input("Enter Source City: ")
    destination = input("Enter Destination City: ")
    date = input("Enter Date (YYYY-MM-DD): ")
    time = input("Enter Time (HH:MM): ")
    seats = int(input("Enter Total Seats: "))
    price = float(input("Enter Ticket Price: "))

    # ✅ Generate flight number automatically (e.g., AI001, AI002)
    cur.execute("SELECT COUNT(*) FROM flights")
    total_flights = cur.fetchone()[0] + 1
    flight_no = f"AI{total_flights:03d}"

    cur.execute("""
        INSERT INTO flights (flight_no, name, source, destination, date, time, seats, price)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (flight_no, name, source, destination, date, time, seats, price))

    conn.commit()
    conn.close()
    print(f"✅ Flight added successfully! Flight No: {flight_no}")


def view_flights():
    conn = sqlite3.connect("airline.db")
    cur = conn.cursor()

    print("\n===== 🛫 All Available Flights =====")

    # ✅ Corrected: removed invalid 'id' column
    cur.execute("SELECT flight_id, name, source, destination, date, time, seats, price FROM flights")
    flights = cur.fethall()

    if flights:
        print(f"{'Flight No':<10} {'Airline':<20} {'From':<15} {'To':<15} {'Date':<12} {'Time':<8} {'Seats':<8} {'Price (₹)':<10}")
        print("-" * 100)
        for f in flights:
            print(f"{f[0]:<10} {f[1]:<20} {f[2]:<15} {f[3]:<15} {f[4]:<12} {f[5]:<8} {f[6]:<8} ₹{f[7]:<10}")
    else:
        print("❌ No flights found.")

    conn.close()




def delete_flight():
    conn = sqlite3.connect("airline.db")
    cur = conn.cursor()
    flight_id = input("Enter Flight Number to Delete: ")
    cur.execute("DELETE FROM flights WHERE flight_id = ?", (flight_id,))
    conn.commit()

    if cur.rowcount > 0:
        print("\n🗑️  Flight deleted successfully!\n")
    else:
        print("\n⚠️ No flight found with that number!\n")

    conn.close()

def view_passengers():
    conn = sqlite3.connect("airline.db")
    c = conn.cursor()

    c.execute("""
    SELECT u.name, f.flight_no, f.name, f.source, f.destination, f.date, f.time
    FROM bookings b
    JOIN users u ON b.user_id = u.id
    JOIN flights f ON b.flight_id = f.flight_id
""")

    passengers = c.fetchall()

    print("\n===== 👥 Passenger List =====")
    for p in passengers:
        print(f"{p[0]} | {p[1]} | {p[2]} | {p[3]} → {p[4]} | {p[5]} | {p[6]}")
    
    choice = input("\nDo you want to export this list to PDF? (y/n): ")
    if choice.lower() == 'y':
        export_passenger_list_to_pdf(passengers)

    conn.close()

def update_flight():
    conn = sqlite3.connect("airline.db")
    cur = conn.cursor()

    print("\n===== ✏️ Update Flight Details =====")
    flight_id = input("Enter Flight Number to Update: ")

    # ✅ Check if flight exists (corrected column name)
    cur.execute("SELECT * FROM flights WHERE flight_id=?", (flight_id,))
    flight = cur.fetchone()

    if not flight:
        print("❌ Flight not found.")
        conn.close()
        return

    print("\nCurrent Flight Details:")
    print(f"Flight No: {flight[1]}, Airline: {flight[2]}, From: {flight[3]} → {flight[4]}")
    print(f"Date: {flight[5]}, Time: {flight[6]}, Seats: {flight[7]}, Price: ₹{flight[8]}")

    # ✅ Get new details (press Enter to keep same)
    new_name = input(f"Enter new Airline Name ({flight[2]}): ") or flight[2]
    new_source = input(f"Enter new Source City ({flight[3]}): ") or flight[3]
    new_dest = input(f"Enter new Destination City ({flight[4]}): ") or flight[4]
    new_date = input(f"Enter new Date ({flight[5]}): ") or flight[5]
    new_time = input(f"Enter new Time ({flight[6]}): ") or flight[6]
    new_seats = input(f"Enter new Total Seats ({flight[7]}): ") or flight[7]

    # ✅ Handle price safely
    new_price_input = input(f"Enter new Ticket Price (₹{flight[8]}): ")
    try:
        new_price = float(new_price_input) if new_price_input else flight[8]
    except ValueError:
        print("⚠️ Invalid price entered. Keeping old price.")
        new_price = flight[8]

    # ✅ Update (fixed column name)
    cur.execute("""
        UPDATE flights
        SET name=?, source=?, destination=?, date=?, time=?, seats=?, price=?
        WHERE flight_id=?
    """, (new_name, new_source, new_dest, new_date, new_time, new_seats, new_price, flight_id))

    conn.commit()
    conn.close()
    print("✅ Flight updated successfully!")



# --- Admin Menu ---
def admin_menu():
    while True:
        print("\n===== ✈️ Airline Admin Menu =====")
        print("1. Add Flight")
        print("2. View Flights")
        print("3. Delete Flight")
        print("4. View Passengers")
        print("5. Update Flight")
        print("6. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            add_flight()
        elif choice == "2":
            view_flights()
        elif choice == "3":
            delete_flight()
        elif choice == "4":
            view_passengers()
        elif choice == "5":
            update_flight()
        elif choice == "6":
            print("\n👋 Exiting Admin Menu...\n")
            break
        else:
            print("\n❌ Invalid choice! Try again.\n")


# 🔽 THIS PART IS VERY IMPORTANT 🔽
if __name__ == "__main__":
    admin_menu()
