import sqlite3

# Connect to the database
conn = sqlite3.connect("airline.db")
cur = conn.cursor()

print("⚙️ Recreating flights table...")

# ===== Recreate Flights Table =====
cur.execute("DROP TABLE IF EXISTS flights")

cur.execute("""
CREATE TABLE flights (
    flight_id INTEGER PRIMARY KEY AUTOINCREMENT,
    flight_no TEXT,
    name TEXT,
    source TEXT,
    destination TEXT,
    date TEXT,
    time TEXT,
    seats INTEGER,
    price REAL
)
""")

print("✅ flights table recreated successfully with 'price' and proper ID!")

# ===== Create Users Table =====
cur.execute("""
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT,
    email TEXT UNIQUE,
    password TEXT
)
""")

# ===== Create Bookings Table =====
cur.execute("""
CREATE TABLE IF NOT EXISTS bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    flight_id INTEGER,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (flight_id) REFERENCES flights(flight_id)
)
""")

# Commit and close
conn.commit()
conn.close()

print("✅ All tables created successfully!")
