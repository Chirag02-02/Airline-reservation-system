import sqlite3

conn = sqlite3.connect("airline.db")
cur = conn.cursor()

print("\n=== DATABASE SCHEMA ===")
for row in cur.execute("SELECT sql FROM sqlite_master WHERE type='table'"):
    print(row[0])
    print("-" * 50)

print("\n=== USERS TABLE ===")
for row in cur.execute("SELECT * FROM users"):
    print(row)

print("\n=== ADMIN TABLE ===")
for row in cur.execute("SELECT * FROM admin"):
    print(row)

print("\n=== FLIGHTS TABLE ===")
for row in cur.execute("SELECT * FROM flights"):
    print(row)

print("\n=== BOOKINGS TABLE ===")
for row in cur.execute("SELECT * FROM bookings"):
    print(row)

conn.close()
