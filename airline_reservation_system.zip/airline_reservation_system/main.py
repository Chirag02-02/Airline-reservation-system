import os

# Run Admin Panel
def run_admin():
    os.system("python admin.py")

# Run User Panel
def run_user():
    os.system("python user.py")

# Main Menu
def main_menu():
    while True:
        print("\n===== 🌍 Airline Reservation System =====")
        print("1. Admin Panel (For Flight Management)")
        print("2. User Panel (For Booking Tickets)")
        print("3. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            run_admin()
        elif choice == "2":
            run_user()
        elif choice == "3":
            print("👋 Thank you for using Airline Reservation System!")
            break
        else:
            print("❌ Invalid choice. Try again!")

if __name__ == "__main__":
    main_menu()
