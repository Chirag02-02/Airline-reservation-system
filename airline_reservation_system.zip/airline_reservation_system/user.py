import sqlite3
import getpass

from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import datetime

import datetime
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

def export_bookings_to_pdf(username, bookings):
    filename = f"{username}_bookings_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    c = canvas.Canvas(filename, pagesize=letter)
    width, height = letter

    c.setFont("Helvetica-Bold", 16)
    c.drawString(180, height - 50, "🧾 Flight Bookings Summary")

    c.setFont("Helvetica", 12)
    y = height - 100
    for i, booking in enumerate(bookings, start=1):
        c.drawString(50, y, f"{i}. Flight No: {booking[1]}")
        c.drawString(200, y, f"Airline: {booking[2]}")
        y -= 15
        c.drawString(50, y, f"From: {booking[3]} → To: {booking[4]}")
        y -= 15
        c.drawString(50, y, f"Date: {booking[4]} | Time: {booking[5]}")

        y -= 25
        if y < 100:
            c.showPage()
            y = height - 100

    c.save()
    print(f"📄 All bookings exported to '{filename}'")
    
def export_passenger_list_to_pdf(passengers):
    from reportlab.lib.pagesizes import letter
    from reportlab.pdfgen import canvas

    filename = "passenger_list.pdf"
    c = canvas.Canvas(filename, pagesize=letter)

    c.setFont("Helvetica-Bold", 16)
    c.drawString(200, 750, "Passenger Booking List")

    c.setFont("Helvetica", 12)
    y = 720
    for p in passengers:
        # Assuming order: username, flight_no, name, source, destination, date, time
        c.drawString(50, y, f"Username: {p[0]} | Flight No: {p[1]}")
        y -= 20
        c.drawString(50, y, f"Airline: {p[2]} | From: {p[3]} → To: {p[4]}")
        y -= 20
        c.drawString(50, y, f"Date: {p[5]} | Time: {p[6]}")
        y -= 30

        if y < 100:  # start a new page if space runs out
            c.showPage()
            c.setFont("Helvetica", 12)
            y = 750

    c.save()
    print(f"✅ Passenger list exported as {filename}")



def generate_receipt(filename, title, details):
    c = canvas.Canvas(filename, pagesize=letter)
    width, height = letter

    c.setFont("Helvetica-Bold", 18)
    c.drawString(200, 750, title)

    c.setFont("Helvetica", 12)
    y = 700
    for key, value in details.items():
        c.drawString(100, y, f"{key}: {value}")
        y -= 25

    c.drawString(100, 100, f"Generated on: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    c.save()


# Connect to the database
def connect_db():
    return sqlite3.connect("airline.db")

# Register a new user
def register():
    conn = connect_db()
    cur = conn.cursor()

    print("\n===== 🧍 User Registration =====")
    name = input("Enter your name: ")
    email = input("Enter your email: ")
    password = getpass.getpass("Enter your password (hidden): ")

    cur.execute("INSERT INTO users (name, email, password) VALUES (?, ?, ?)", 
                (name, email, password))
    conn.commit()
    conn.close()
    print("✅ Registration successful! You can now log in.")

# User login
def login():
    conn = connect_db()
    cur = conn.cursor()

    print("\n===== 🔐 User Login =====")
    email = input("Enter your email: ")
    password = getpass.getpass("Enter your password: ")

    cur.execute("SELECT * FROM users WHERE email=? AND password=?", (email, password))
    user = cur.fetchone()

    conn.close()
    if user:
        print(f"\n✅ Welcome back, {user[1]}!")
        user_menu(user[0], user[1])
    else:
        print("❌ Invalid email or password.")
        
import sqlite3

def search_flight():
    conn = sqlite3.connect("airline.db")
    cur = conn.cursor()

    print("\n===== 🔍 Search Flights by City =====")
    source = input("Enter Source City: ").strip().lower()
    destination = input("Enter Destination City: ").strip().lower()

    cur.execute("SELECT * FROM flights WHERE LOWER(source)=? AND LOWER(destination)=?", (source, destination))
    flights = cur.fetchall()

    if flights:
        print("\nAvailable Flights:")
        print("-" * 80)
        for flight in flights:
            print(f"Flight No: {flight[0]} | Airline: {flight[1]} | Source: {flight[2]} | Destination: {flight[3]} | Date: {flight[4]} | Time: {flight[5]} | Seats: {flight[6]}")
        print("-" * 80)
    else:
        print("❌ No flights found for the given route.")

    conn.close()
    


# Show all available flights
import sqlite3

def view_flights():
    conn = sqlite3.connect("airline.db")
    cur = conn.cursor()

    print("\n===== 🛫 All Available Flights =====")

    cur.execute("""
        SELECT flight_id, flight_no, name, source, destination, date, time, seats, price 
        FROM flights
        ORDER BY date, time
    """)
    flights = cur.fetchall()

    if flights:
        print(f"{'ID':<5} {'Flight No':<10} {'Airline':<20} {'From':<15} {'To':<15} {'Date':<12} {'Time':<8} {'Seats':<8} {'Price (₹)':<10}")
        print("-" * 105)

        for f in flights:
            print(f"{f[0]:<5} {f[1]:<10} {f[2]:<20} {f[3]:<15} {f[4]:<15} {f[5]:<12} {f[6]:<8} {f[7]:<8} ₹{f[8]:<10.2f}")
    else:
        print("❌ No flights found.")

    conn.close()


# Book a flight
def book_flight(user_id):
    conn = sqlite3.connect("airline.db")
    cur = conn.cursor()

    print("\n===== 🎫 Book a Flight =====")
    flight_id = input("Enter Flight ID to Book: ")

    # ✅ Check if flight exists
    cur.execute("SELECT * FROM flights WHERE flight_id=?", (flight_id,))
    flight = cur.fetchone()

    if flight:
        seats = int(flight[7])
        price = float(flight[8])

        if seats > 0:
            print(f"\n💰 Ticket Price: ₹{price}")
            print("Choose Payment Method:")
            print("1. UPI")
            print("2. Debit/Credit Card")
            print("3. Net Banking")

            payment_choice = input("Enter your choice (1/2/3): ")

            if payment_choice == "1":
                upi_id = input("Enter your UPI ID: ")
                print(f"Processing UPI payment for {upi_id} ...")
            elif payment_choice == "2":
                card_no = input("Enter last 4 digits of your card: ")
                print(f"Processing card payment **** **** **** {card_no} ...")
            elif payment_choice == "3":
                bank_name = input("Enter your bank name: ")
                print(f"Connecting to {bank_name} Net Banking ...")
            else:
                print("❌ Invalid payment method. Try again.")
                conn.close()
                return

            print("✅ Payment Successful!")

            # ✅ Save booking
            cur.execute("INSERT INTO bookings (user_id, flight_id) VALUES (?, ?)", (user_id, flight[0]))

            # ✅ Reduce available seats
            cur.execute("UPDATE flights SET seats = seats - 1 WHERE flight_id=?", (flight_id,))
            conn.commit()

            # 🧾 Display booking receipt
            print("\n===== 🧾 Booking Receipt =====")
            print(f"Passenger ID: {user_id}")
            print(f"Flight ID: {flight[0]}")
            print(f"Flight No: {flight[1]}")
            print(f"Airline: {flight[2]}")
            print(f"From: {flight[3]} → To: {flight[4]}")
            print(f"Date: {flight[5]} | Time: {flight[6]}")
            print(f"Amount Paid: ₹{price}")
            print("Status: ✅ Confirmed")
            print(f"Remaining Seats: {seats - 1}")
            print("==============================")

        else:
            print("❌ Sorry, no seats available for this flight.")
    else:
        print("❌ Flight not found.")

    conn.close()

def view_my_bookings(user_id, username):
    conn = sqlite3.connect("airline.db")
    cur = conn.cursor()

    print("\n===== 📜 My Bookings =====")

    # ✅ Join using flight_id (new schema)
    cur.execute("""
        SELECT f.flight_no, f.name, f.source, f.destination, f.date, f.time
        FROM bookings b
        JOIN flights f ON b.flight_id = f.flight_id
        WHERE b.user_id = ?
    """, (user_id,))

    bookings = cur.fetchall()

    if bookings:
        print("Flight No | Airline | From → To | Date | Time")
        print("--------------------------------------------------")
        for b in bookings:
            print(f"{b[0]} | {b[1]} | {b[2]} → {b[3]} | {b[4]} | {b[5]}")

        # ✅ Ask for export once (outside the loop)
        choice = input("\nDo you want to export these bookings to PDF? (y/n): ")
        if choice.lower() == 'y':
            export_bookings_to_pdf(username, bookings)
            print("📄 Bookings exported successfully!")
    else:
        print("❌ You have no bookings yet.")

    conn.close()


def search_flights():
    conn = sqlite3.connect("airline.db")
    cur = conn.cursor()

    print("\n===== 🔍 Search Flights =====")
    source = input("Enter Source City: ").strip()
    destination = input("Enter Destination City: ").strip()
    date = input("Enter Date (YYYY-MM-DD): ").strip()

    cur.execute("""
        SELECT flight_no, name, source, destination, date, time, seats, price
        FROM flights
        WHERE source=? AND destination=? AND date=?
    """, (source, destination, date))

    flights = cur.fetchall()

    if flights:
        print("\nAvailable Flights:")
        print(f"{'Flight No':<10} {'Airline':<20} {'From':<15} {'To':<15} {'Date':<12} {'Time':<8} {'Seats':<6} {'Price (₹)':<10}")
        print("-" * 100)
        for f in flights:
            # Handle any None values safely
            flight_no = f[0] if f[0] else "N/A"
            name = f[1] if f[1] else "Unknown Airline"
            source = f[2] if f[2] else "-"
            destination = f[3] if f[3] else "-"
            date = f[4] if f[4] else "-"
            time = f[5] if f[5] else "-"
            seats = f[6] if f[6] is not None else 0
            price = f[7] if f[7] is not None else 0

            print(f"{flight_no:<10} {name:<20} {source:<15} {destination:<15} {date:<12} {time:<8} {seats:<6} ₹{price:<10}")
    else:
        print("❌ No flights found for the given route and date.")

    conn.close()




# View user bookings
def view_bookings(user_id):
    conn = connect_db()
    cur = conn.cursor()

    cur.execute("""
        SELECT b.id, f.flight_no, f.name, f.source, f.destination, f.date, f.time
        FROM bookings b
        JOIN flights f ON b.flight_id = f.id
        WHERE b.user_id=?
    """, (user_id,))

    bookings = cur.fetchall()
    print("\n===== 🧾 Your Bookings =====")
    if not bookings:
        print("You have no bookings yet.")
    else:
        for b in bookings:
            print(f"Booking ID: {b[0]} | {b[1]} - {b[2]} | {b[3]} → {b[4]} | {b[5]} {b[6]}")
    conn.close()

# Cancel booking
def cancel_booking(user_id):
    conn = sqlite3.connect("airline.db")
    cur = conn.cursor()

    print("\n===== ❌ Cancel a Booking =====")
    flight_no = input("Enter Flight Number to Cancel: ")

    # ✅ Find flight details using new schema
    cur.execute("SELECT flight_id, flight_no, name, source, destination, date, time FROM flights WHERE flight_no=?", (flight_no,))
    flight = cur.fetchone()

    if not flight:
        print("❌ Flight not found.")
        conn.close()
        return

    flight_id = flight[0]

    # ✅ Check if the user has booked this flight
    cur.execute("SELECT * FROM bookings WHERE user_id=? AND flight_id=?", (user_id, flight_id))
    booking = cur.fetchone()

    if booking:
        # Delete booking
        cur.execute("DELETE FROM bookings WHERE user_id=? AND flight_id=?", (user_id, flight_id))

        # Restore seat count
        cur.execute("UPDATE flights SET seats = seats + 1 WHERE flight_no=?", (flight_no,))
        conn.commit()

        # 🧾 Display Cancellation Receipt
        print("\n===== ❌ Cancellation Receipt =====")
        print(f"Passenger ID: {user_id}")
        print(f"Flight No: {flight[1]}")
        print(f"Airline: {flight[2]}")
        print(f"From: {flight[3]} → To: {flight[4]}")
        print(f"Date: {flight[5]} | Time: {flight[6]}")
        print("Status: ✅ Cancelled Successfully")
        print("Refund: Initiated 💰")
        print("==================================")

        # 🧾 Generate cancellation PDF receipt
        receipt_details = {
            "Passenger ID": user_id,
            "Flight Number": flight[1],
            "Airline": flight[2],
            "From": flight[3],
            "To": flight[4],
            "Date": flight[5],
            "Time": flight[6],
            "Status": "Cancelled",
            "Refund": "Initiated 💰"
        }

        generate_receipt(
            f"cancel_receipt_{user_id}_{flight[1]}.pdf",
            "Flight Cancellation Receipt",
            receipt_details
        )

        print(f"📄 Receipt saved as cancel_receipt_{user_id}_{flight[1]}.pdf")

    else:
        print("❌ No such booking found for this flight.")

    conn.close()


#User menu
def user_menu(user_id, username):
    while True:
        print(f"\n===== 👋 Welcome, {username}! =====")
        print("1. search Flights")
        print("2. View Flights")
        print("3. Book Flight")
        print("4. View My Bookings")
        print("5. Cancel Booking")
        print("6. Search Flight by City")
        print("7. Logout")

        choice = input("Enter your choice: ")
        if choice == "1":
            search_flights()
        if choice == "2":
            view_flights()
        elif choice == "3":
            book_flight(user_id)
        elif choice == "4":
             view_my_bookings(user_id, username)
        elif choice == "5":
            cancel_booking(user_id)
        elif choice == "6":
             search_flight()
        elif choice == "7":
            print("👋 Logged out successfully!")
            break
        else:
            print("❌ Invalid choice. Try again.")

# Main menu
def main_menu():
    while True:
        print("\n===== 🧳 Airline User System =====")
        print("1. Register")
        print("2. Login")
        print("3. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            register()
        elif choice == "2":
            login()
        elif choice == "3":
            print("👋 Goodbye!")
            break
        else:
            print("❌ Invalid choice.")

if __name__ == "__main__":
    main_menu()

