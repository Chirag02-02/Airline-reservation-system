import sqlite3

conn = sqlite3.connect("airline.db")
cur = conn.cursor()

# ✅ Rename old table
cur.execute("ALTER TABLE users RENAME TO users_old;")

# ✅ Create new table with created_at column
cur.execute("""
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
""")

# ✅ Copy data from old table into new one
cur.execute("INSERT INTO users (id, name, email, password) SELECT id, name, email, password FROM users_old;")

# ✅ Drop old table
cur.execute("DROP TABLE users_old;")

conn.commit()
conn.close()

print("✅ Fixed: 'created_at' column added successfully to users table.")
